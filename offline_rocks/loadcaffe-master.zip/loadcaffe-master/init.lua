require 'nn'
loadcaffe = {}
include 'ffi.lua'
include 'loadcaffe.lua'
return loadcaffe
