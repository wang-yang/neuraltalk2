#ifndef THC_STORAGE_COPY_INC
#define THC_STORAGE_COPY_INC

#include "THCStorage.h"
#include "THCGeneral.h"
#include "THCHalf.h"

#include "generic/THCStorageCopy.h"
#include "THCGenerateAllTypes.h"

#endif
