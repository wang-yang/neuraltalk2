#include "THCStorageCopy.h"
#include "THCGeneral.h"

#include "THCHalf.h"

#include "generic/THCStorageCopy.c"
#include "THCGenerateAllTypes.h"
