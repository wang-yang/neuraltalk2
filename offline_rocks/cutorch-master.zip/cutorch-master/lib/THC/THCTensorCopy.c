#include "THCTensorCopy.h"
#include "THCGeneral.h"
#include "THCTensor.h"

#include "THCHalf.h"

#include "generic/THCTensorCopy.c"
#include "THCGenerateAllTypes.h"
