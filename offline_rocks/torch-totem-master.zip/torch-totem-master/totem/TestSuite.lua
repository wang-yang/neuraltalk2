require 'torch'

function totem.TestSuite()
  return torch.TestSuite()
end
