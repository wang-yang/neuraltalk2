 h5read /Users/daniel.horgan/test.h5 /dset
