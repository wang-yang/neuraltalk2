return {
    data1 = torch.linspace(0, 100, 100):resize(10, 10):float(),
    data2 = torch.linspace(0, 10, 100):resize(10, 10):float(),
}