return {
    data = torch.linspace(0, 100, 100):resize(10, 10):float(),
}